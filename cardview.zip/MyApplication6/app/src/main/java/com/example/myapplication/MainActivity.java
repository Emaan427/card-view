package com.example.myapplication;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView courseRV = findViewById(R.id.idRVCourse);

        // Here, we have created new array list and added data to it
        ArrayList<courseModel> courseModelArrayList = new ArrayList<courseModel>();
        courseModelArrayList.add(new courseModel("DSA in Java", 4, R.drawable.img));
        courseModelArrayList.add(new courseModel("Java Course", 3, R.drawable.img));
        courseModelArrayList.add(new courseModel("C++ Course", 4, R.drawable.img));
        courseModelArrayList.add(new courseModel("DSA in C++", 4, R.drawable.img));
        courseModelArrayList.add(new courseModel("Kotlin for Android", 4, R.drawable.img));
        courseModelArrayList.add(new courseModel("Java for Android", 4, R.drawable.img));
        courseModelArrayList.add(new courseModel("HTML and CSS", 4, R.drawable.img));

        // we are initializing our adapter class and passing our arraylist to it.
        CourseAdapter courseAdapter = new CourseAdapter(this, courseModelArrayList);

        // below line is for setting a layout manager for our recycler view.
        // here we are creating vertical list so we will provide orientation as vertical
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        // in below two lines we are setting layoutmanager and adapter to our recycler view.
        courseRV.setLayoutManager(linearLayoutManager);
        courseRV.setAdapter(courseAdapter);
    }
}
